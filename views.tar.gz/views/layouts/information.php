



<div class="row">
    <!-- /.box -->
    <div class="box">
        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-condensed OperatorInfo">
                <tbody>
                <tr>

                    <td align="center">اخبار</td>
                    <td align="center">اخبار ایران و جهان</td>
                    <td align="center">آب و هوا</td>
                    <td align="center">چند رسانه ای</td>
                    <td align="center">گالری</td>
                </tr>
                <tr>

                    <td align="center">
                        <span name="txtCountOp" class="badge bg-green">0</span></td>
                    <td align="center">
                        <span name="txtCountActiveOp" class="badge bg-green">0</span></td>
                    <td align="center">
                        <span name="txtUnLocal" class="badge bg-green">0</span></td>
                    <td align="center">
                        <span name="txtTotalTime" class="badge bg-green">0</span></td>
                    <td align="center">
                        <span name="txtAvgTime" class="badge bg-green">0</span></td>
                </tr>
                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
    <!-- /.col -->
    <!-- /.box -->
    <div class="box">

        <!-- /.box-header -->
        <div class="box-body no-padding">
            <table class="table table-striped OperatorInfo">
                <tbody>
                <tr>
                    <td align="center">بوم گردی</td>
                    <td align="center">موسیقی</td>
                    <td align="center">استخدام</td>
                    <td align="center">بازارچه</td>
                    <td align="center">حرف مردم</td>
                </tr>
                <tr>
                    <td align="center">
                        <span name="txtEnteredCall" class="badge bg-red">0</span></td>
                    <td align="center">
                        <span name="txt401402" class="badge bg-red">0</span></td>
                    <td align="center">
                        <span name="txt301304219" class="badge bg-red">0</span></td>
                    <td align="center">
                        <span name="txt203" class="badge bg-red">0</span></td>
                    <td align="center">
                        <span name="txtDisturber" class="badge bg-red">0</span></td>
                </tr>
                <tr>

                </tr>
                <tr>

                </tr>
                <tr>
                </tr>
                </tbody>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <!-- /.box -->
    <!-- /.col -->
</div>

