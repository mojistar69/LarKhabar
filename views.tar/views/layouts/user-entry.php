<body class="hold-transition login-page">

	<?= $content ?>


</body>
