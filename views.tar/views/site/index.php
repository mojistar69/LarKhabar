<?php
use app\models\City;
use app\models\Zone;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\widgets\Breadcrumbs;
use app\widgets\Alert;
/* @var $this yii\web\View */

$this->title = 'سامانه 118';
$identity=Yii::$app->user->identity;
var_dump($identity);
?>




